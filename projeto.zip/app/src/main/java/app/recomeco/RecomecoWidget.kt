package app.recomeco

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/** Widget real: dias + cronômetro (Chronometer corre sozinho, sem gastar bateria com atualizações). */
class RecomecoWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
        schedule(context)
    }

    companion object {
        private const val DAY = 86_400_000L

        fun build(ctx: Context): RemoteViews {
            val p = ctx.getSharedPreferences("w", 0)
            val name = p.getString("name", "") ?: ""
            val start = p.getLong("start", 0L)
            val now = System.currentTimeMillis()
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.root, open)
            if (name.isEmpty() || start <= 0L || start > now) {
                v.setTextViewText(R.id.title, "Recomeço")
                v.setTextViewText(R.id.days, "—")
                v.setTextViewText(R.id.unit, "Abra o app para começar")
                v.setViewVisibility(R.id.chrono, View.GONE)
            } else {
                val el = now - start
                val d = el / DAY
                v.setTextViewText(R.id.title, name)
                v.setTextViewText(R.id.days, d.toString())
                v.setTextViewText(R.id.unit, if (d == 1L) "dia" else "dias")
                v.setViewVisibility(R.id.chrono, View.VISIBLE)
                v.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() - (el % DAY), null, true)
            }
            return v
        }

        fun updateAll(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RecomecoWidget::class.java))
            if (ids.isEmpty()) return
            for (id in ids) m.updateAppWidget(id, build(ctx))
            schedule(ctx)
        }

        /** Reagenda uma atualização na virada do próximo dia (para o contador de dias e o cronômetro). */
        fun schedule(ctx: Context) {
            val start = ctx.getSharedPreferences("w", 0).getLong("start", 0L)
            val now = System.currentTimeMillis()
            if (start <= 0L || start > now) return
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RecomecoWidget::class.java))
            if (ids.isEmpty()) return
            val next = start + ((now - start) / DAY + 1) * DAY + 1000L
            val i = Intent(ctx, RecomecoWidget::class.java)
            i.action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            val pi = PendingIntent.getBroadcast(
                ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
        }
    }
}
