package app.recomeco

import android.webkit.JavascriptInterface
import org.json.JSONObject

/** Ponte JavaScript → Android. Só recebe texto do próprio app (nenhuma página externa é carregada). */
class Bridge(private val a: MainActivity) {
    @JavascriptInterface
    fun sync(json: String) {
        try {
            val o = JSONObject(json)
            a.getSharedPreferences("w", 0).edit()
                .putString("name", o.optString("name", ""))
                .putLong("start", o.optLong("start", 0L))
                .apply()
            RecomecoWidget.updateAll(a)
        } catch (e: Exception) {
        }
    }

    @JavascriptInterface
    fun saveFile(name: String, text: String) {
        a.runOnUiThread { a.exportFile(name, text) }
    }
}
